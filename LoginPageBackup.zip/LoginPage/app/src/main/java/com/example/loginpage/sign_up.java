package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.MessageDigest;
import java.net.*;
import java.io.*;

public class sign_up extends AppCompatActivity {


    private String email;
    private String password;
    private String confirmPassword;

    private EditText emailET;
    private EditText passwordET;
    private EditText confirmPasswordET;

    private String hashedString = "";
    private String usernameString = "";


    private Socket s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        EditText emailET = findViewById(R.id.emailInput);
        EditText passwordET = findViewById(R.id.passwordInput);
        EditText confirmPasswordET = findViewById(R.id.confirmPasswordInput);


    }

    @Override
    public void finish() {

        super.finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }

    public String Hash(String hashString)
    {
        String hash = "";
        try{
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] stringBytes = hashString.getBytes();
            messageDigest.update(stringBytes);

            byte[] digestedBytes = messageDigest.digest();
            hash = bytesToHex(digestedBytes).toLowerCase();
        }
        catch(Exception e)
        {
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(getBaseContext(), "Hash Error has Occurred!",duration);
            toast.show();
        }
        return hash;
    }


    public void signupButtonClick(View view) {

        email = String.valueOf(emailET);
        password = String.valueOf(passwordET);
        confirmPassword = String.valueOf(confirmPasswordET);

        /*if(password.isEmpty()){
            Toast.makeText(getBaseContext(), "Please enter your password!", Toast.LENGTH_SHORT).show();
        }
        if(password != confirmPassword){
            Toast.makeText(getBaseContext(), "Passwords do not match!", Toast.LENGTH_SHORT).show();
        }
        if(email == ""){
            Toast.makeText(getBaseContext(), "Please enter your Email address!", Toast.LENGTH_SHORT).show();
        }*/


        if(!password.isEmpty() && password == confirmPassword && !email.isEmpty()) {


        }

        //Send s = ;Hash(password)
        hashedString = Hash(password);
        usernameString = email;

        Toast.makeText(getBaseContext(), "Sending Data...", Toast.LENGTH_SHORT).show();
        System.out.println("Hash1231: " + Hash(password));

        /*
        //Sending data through socket
        SendSocket s = new SendSocket();
        s.execute("192.168.204.1","I am sending!");
        SendSocket s1 = new SendSocket();
        s1.execute("192.168.204.1",usernameString);*/


    //Create a socket doInBackground class -> create read/write threads within the class -> read and write messages through the socket connection
    }


    //Converting Bytes to Hex
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }
/*
    public class SendSocket extends AsyncTask<String,Void,String> {

        Socket s;
        DataOutputStream dos;
        String ip,msg;

        @Override
        protected String doInBackground(String... params) {

            ip = params[0];
            msg = params[1];

            try {
                s = new Socket(ip, 9090);
                dos = new DataOutputStream(s.getOutputStream());
                dos.writeUTF(msg);
                //dos.close();
                //s.close();
                Toast.makeText(getBaseContext(), "Data Sent Successfuly!!!", Toast.LENGTH_SHORT).show();

            } catch (IOException e) {
                e.printStackTrace();
                //Toast.makeText(sign_up.this, "Failed to send socket: " + e.toString(), Toast.LENGTH_SHORT).show();

            }
            return null;
        }
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }
        @Override
        protected void onPostExecute(String s)
        {
            super.onPostExecute(s);
        }
    }*/

}
