package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    private Socket s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
    public void showLoginPage(View view)
    {
        Intent loginIntent = new Intent(MainActivity.this, LoginPage.class);
        startActivity(loginIntent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }
    public void showSignupPage(View view)
    {
        Intent signupIntent = new Intent(MainActivity.this, sign_up.class);
        startActivity(signupIntent);
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
    }
    class ClientThread implements Runnable {

        @Override
        public void run() {
            try {
                InetAddress serverAddr = InetAddress.getByName("192.168.204.1");
                s = new Socket(serverAddr, 9090);
                System.out.println("Connected! " + s.getInetAddress());
            } catch (Exception e1) {
                e1.printStackTrace();
            }

        }
    }
}

